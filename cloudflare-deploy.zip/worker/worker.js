// Cloudflare Worker: קבלת פניות והזמנות מהאתר. חינמי.
// נדרש: KV Namespace בשם DB, וסוד (Secret) בשם ADMIN_KEY. אופציונלי: ALLOW_ORIGIN (כתובת האתר שלכם).
const J=(o,s=200,h={})=>new Response(JSON.stringify(o),{status:s,headers:{'Content-Type':'application/json',...h}});
const PAGE=`<!doctype html><html lang="he" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ניהול פניות</title>
<body style="font-family:Arial,sans-serif;background:#111;color:#f1ece0;padding:16px"><h2>ניהול פניות והזמנות</h2>
<input id=k type=password placeholder="מפתח ניהול" style="padding:8px"> <select id=t style="padding:8px"><option value=lead>פניות</option><option value=order>הזמנות</option></select>
<button id=go style="padding:8px 14px">טעינה</button> <button id=csv style="padding:8px 14px">הורדת CSV</button>
<div style="overflow:auto"><table id=tb border=1 cellpadding=6 style="border-collapse:collapse;margin-top:14px;background:#1b1b20"></table></div>
<script>
let rows=[];const $=s=>document.querySelector(s);
async function load(){const r=await fetch('/api/leads?type='+$('#t').value,{headers:{'X-Admin-Key':$('#k').value}});if(!r.ok){alert('מפתח שגוי או שגיאה');return}rows=await r.json();draw()}
function cols(){return[...new Set(rows.flatMap(r=>Object.keys(r)))]}
function draw(){const c=cols(),t=$('#tb');t.textContent='';const h=t.insertRow();c.forEach(k=>{const e=document.createElement('th');e.textContent=k;h.append(e)});rows.forEach(r=>{const w=t.insertRow();c.forEach(k=>{w.insertCell().textContent=typeof r[k]=='object'?JSON.stringify(r[k]):(r[k]??'')})})}
$('#go').onclick=load;$('#csv').onclick=()=>{const c=cols(),q=v=>'"'+String(typeof v=='object'?JSON.stringify(v):(v??'')).replace(/"/g,'""')+'"',s='\\ufeff'+[c.map(q).join(',')].concat(rows.map(r=>c.map(k=>q(r[k])).join(','))).join('\\n'),a=document.createElement('a');a.href=URL.createObjectURL(new Blob([s],{type:'text/csv'}));a.download='export.csv';a.click()}
<\/script></body></html>`;
export default{async fetch(req,env){
const u=new URL(req.url),p=u.pathname,cors={'Access-Control-Allow-Origin':env.ALLOW_ORIGIN||'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type,X-Admin-Key'};
if(req.method=='OPTIONS')return new Response(null,{headers:cors});
if(p=='/admin')return new Response(PAGE,{headers:{'Content-Type':'text/html;charset=utf-8'}});
if(req.method=='POST'&&(p=='/api/form'||p=='/api/order')){
 const raw=await req.text();if(raw.length>20000)return J({error:'too big'},413,cors);
 let d;try{d=JSON.parse(raw)}catch{return J({error:'bad json'},400,cors)}
 if(d._h)return J({ok:true},200,cors);
 const type=p=='/api/order'?'order':'lead',key=type+':'+String(Date.now()).padStart(15,'0')+':'+crypto.randomUUID().slice(0,6);
 await env.DB.put(key,JSON.stringify({time:new Date().toISOString(),...d}));return J({ok:true},200,cors)}
if(p=='/api/leads'&&req.method=='GET'){
 if(!env.ADMIN_KEY||req.headers.get('X-Admin-Key')!==env.ADMIN_KEY)return J({error:'unauthorized'},401,cors);
 const type=u.searchParams.get('type')=='order'?'order':'lead',l=await env.DB.list({prefix:type+':',limit:1000});
 const out=await Promise.all(l.keys.map(async k=>JSON.parse(await env.DB.get(k.name))));return J(out.reverse(),200,cors)}
return J({ok:true,service:'forms-worker'},200,cors)}};
